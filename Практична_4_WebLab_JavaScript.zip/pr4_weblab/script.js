/* Інтерактивність WebLab */
"use strict";

const navigation = {
  init() {
    const toggle = document.querySelector(".menu-toggle");
    const menu = document.querySelector("#main-nav");
    if (!toggle || !menu) return;

    toggle.addEventListener("click", () => {
      const isOpen = menu.classList.toggle("open");
      toggle.setAttribute("aria-expanded", String(isOpen));
      toggle.setAttribute("aria-label", isOpen ? "Закрити меню" : "Відкрити меню");
      toggle.textContent = isOpen ? "×" : "☰";
    });

    menu.addEventListener("click", (event) => {
      if (event.target.closest("a")) {
        menu.classList.remove("open");
        toggle.setAttribute("aria-expanded", "false");
        toggle.setAttribute("aria-label", "Відкрити меню");
        toggle.textContent = "☰";
      }
    });
  }
};

const accordion = {
  init() {
    const container = document.querySelector(".accordion");
    if (!container) return;

    // Делегування: один обробник для всіх кнопок акордеона.
    container.addEventListener("click", (event) => {
      const button = event.target.closest(".accordion-trigger");
      if (!button) return;

      const panel = button.closest(".accordion-item").querySelector(".accordion-panel");
      const willOpen = button.getAttribute("aria-expanded") !== "true";
      button.setAttribute("aria-expanded", String(willOpen));
      panel.hidden = !willOpen;
      button.querySelector("span").textContent = willOpen ? "−" : "+";
    });
  }
};

const contactForm = {
  init() {
    const form = document.querySelector("#contact-form");
    if (!form) return;

    const fields = {
      name: document.querySelector("#name"),
      email: document.querySelector("#email"),
      message: document.querySelector("#message")
    };
    const status = document.querySelector("#form-status");

    const showError = (field, message) => {
      document.querySelector(`#${field}-error`).textContent = message;
      fields[field].setAttribute("aria-invalid", message ? "true" : "false");
    };

    form.addEventListener("submit", (event) => {
      event.preventDefault();
      const name = fields.name.value.trim();
      const email = fields.email.value.trim();
      const message = fields.message.value.trim();
      let valid = true;

      const errors = {
        name: name.length < 2 ? "Введіть ім'я (не менше 2 символів)." : "",
        email: /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) ? "" : "Введіть коректну електронну адресу.",
        message: message.length < 10 ? "Повідомлення має містити щонайменше 10 символів." : ""
      };

      Object.entries(errors).forEach(([field, error]) => {
        showError(field, error);
        if (error) valid = false;
      });

      status.className = "form-status";
      if (!valid) {
        status.textContent = "Перевірте, будь ласка, поля з помилками.";
        status.classList.add("failure");
        return;
      }

      // Демонстраційне підтвердження: сервер для надсилання форми не підключено.
      status.textContent = `Дякуємо, ${name}! Дані форми успішно перевірено.`;
      status.classList.add("success");
      form.reset();
      Object.keys(fields).forEach((field) => showError(field, ""));
    });

    Object.entries(fields).forEach(([field, input]) => {
      input.addEventListener("input", () => {
        showError(field, "");
        status.textContent = "";
        status.className = "form-status";
      });
    });
  }
};

document.addEventListener("DOMContentLoaded", () => {
  navigation.init();
  accordion.init();
  contactForm.init();
});
